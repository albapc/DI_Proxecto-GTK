=======================
Estrutura da aplicación
=======================

Arquivos dos que se compón
**************************

Interfaz do menú principal
--------------------------

(PDI_menuPrincipal)
+++++++++++++++++++
.. automodule:: PDI_menuPrincipal
   :members:

Interfaz da xestión de clientes
-------------------------------

(PDI_xestionClientes)
+++++++++++++++++++++
.. automodule:: PDI_xestionClientes
   :members:

Interfaz de produtos e servizos
-------------------------------

(PDI_produtosServizos)
++++++++++++++++++++++
.. automodule:: PDI_produtosServizos
   :members:
