.. ProxectoDI documentation master file, created by
   sphinx-quickstart on Wed Mar 11 15:09:18 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Benvido/a á documentación de ProxectoDI!
========================================

.. toctree::
   :maxdepth: 5
   :caption: Contidos:

   documentacion

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
