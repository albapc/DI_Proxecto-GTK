Documentación
*************

Esta aplicación ten como obxectivo xestionar os datos do clientes que accederon á
tenda para facer as súas compras e engadir datos novos, así como elimina-los datos
obsoletos. Así mesmo, tamén se poderá acceder á lista de produtos dispoñibles e
poder editalos para actualizar os seus datos.